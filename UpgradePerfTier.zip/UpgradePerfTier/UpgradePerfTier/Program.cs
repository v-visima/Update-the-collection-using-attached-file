﻿namespace UpgradePerfTier
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.Azure.Documents;
    using Microsoft.Azure.Documents.Client;

    class Program
    {
        public static void Main(string[] args)
        {
            string uri = "https://<your_database_account>.documents.azure.com:443/";
            string key = "<primary_key_ending_in_==>";
            string databaseName = "<database_name>";
            string collectionName = "<collection_name>";

            //desired level of throughput after performance tier migration - it is best to leave this as 400 (throughput minimum)
            int throughput = 400;

            string status = ChangeOfferType(uri, key, databaseName, collectionName, throughput).Result;
            Console.WriteLine(status);
            Console.WriteLine("Done. Press <enter> to quit");
            Console.ReadLine();
        }

        /// <summary>
        /// ChangeOfferType changes the offer type / throughput of a collection. 
        /// </summary>
        /// <param name="uri"> your database account uri that can be gathered from the keys page on the portal </param>
        /// <param name="key"> your database account master key that can be gathered from the keys page on the portal </param>
        /// <param name="databaseName"> the name of the database that holds the collection for which you want to change throughput </param>
        /// <param name="collectionName"> the name of the collection for which you will change the throughput </param>
        /// <param name="throughput"> the new throughput, 400 by default as it is the lowest and least expensive </param>
        /// <returns> string:: status -> a description of whether or not the offer was modified </returns>
        public static async Task<string> ChangeOfferType(string uri, string key, string databaseName, string collectionName, int throughput = 400)
        {
            try
            {
                using (DocumentClient client = new DocumentClient(new Uri(uri), key))
                {
                    //Create a self link for the desired collection
                    string selfLink = client.CreateDocumentCollectionQuery(
                                        UriFactory.CreateDatabaseUri(databaseName))
                                                .Where(c => c.Id == collectionName)
                                                .AsEnumerable()
                                                .FirstOrDefault()
                                                .SelfLink;

                    //Fetch the resource to be updated
                    Offer offer = client.CreateOfferQuery()
                                        .Where(r => r.ResourceLink == selfLink)
                                        .AsEnumerable()
                                        .SingleOrDefault();

                    //Get and log the current throughput - these lines may not be compatible with your current offer type
                    //so they are commented out.
                    //int throughputCurrent = (int)offer.GetPropertyValue<JObject>("content").GetValue("offerThroughput");
                    //Console.WriteLine("Current throughput: {0}", throughputCurrent.ToString());

                    // Set the throughput. Here we change your offer from Offer to OfferV2
                    offer = new OfferV2(offer, throughput);

                    //Now persist these changes to the database by replacing the original resource
                    await client.ReplaceOfferAsync(offer);

                    return "Throughput succesfully modified.";
                }
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e);
                return "Throughput was not modified.";
            }
        }
    }
}
